if SERVER then
      resource.AddFile("hud_icons/armor.png")
	  resource.AddFile("hud_icons/heart.png")
	  resource.AddFile("hud_icons/food.png")
	  resource.AddFile("hud_icons/bullets.png")
	  
      local sv_res = file.Find('server/*.lua','LUA')
	 for k,v in pairs(sv_res) do
	 include ('server/' .. v)
	 end
	  
	  local res = file.Find('client/*.lua','LUA')
	  for k, v in pairs(res) do
	      AddCSLuaFile('client/'..v)
	  end
end
if CLIENT then 
     local res = file.Find('client/*.lua','LUA')
	 for k,v in pairs(res) do
	 include ('client/' .. v)
	 end
	 
end 
	  
	 print ('Autorun loaded...')