function HideHud(myhud)
for k,v in pairs{'CHudHealth','CHudBattery','CHudAmmo',"DarkRP_HUD","DarkRP_EntityDisplay","DarkRP_ZombieInfo","DarkRP_Hungermod","DarkRP_Agenda"}do 
   if myhud == v then return false 
end
end
end

     surface.CreateFont("DCC-Ash",{
     font = "Arial",
	 size = 35,
	 weight = 1200,
	 antialias = false,
	 outline = true,
	
	 
})

     surface.CreateFont("Job",{
     font = "Arial",
	 size = 20,
	 weight = 800,
	 antialias = false,
	 outline = true,
	 
})

     surface.CreateFont("Money",{
     font = "Arial",
	 size = 20,
	 weight = 800,
	 outline = true,
	 antialias = false,
})
     surface.CreateFont("Bullets",{
     font = "Arial",
	 size = 35,
	 weight = 800,
     antialias = true
})

     surface.CreateFont("Time",{
     font = "Arial",
	 size = 20,
	 weight = 800,
	 antialias = true
})


function painthud()

local lp = LocalPlayer()
local hp = lp:Health()
local arm = lp:Armor()
local nofireweps = {weapon_crowbar, weapon_physcannon, gmod_tool, weapon_keypadchecker, weapon_gravitycannon }
local granade = {weapon_fraggranade = true}
local money = lp:getDarkRPVar('money')
local rpname = lp:getDarkRPVar('rpname')
local job = lp:getDarkRPVar('job')

c1 = 0
c2 = 255
c3 = 0
c4 = 255

c5 = 0
c6 = 255
c7 = 0
c8 = 255

if hp < 50 then
c1 = 255
c2 = 255
c3 = 0
c4 = 255

end

if arm < 50 then
c5 = 255
c6 = 255
c7 = 0
c8 = 255

end
local function reserveammo()
if IsValid(LocalPlayer():GetActiveWeapon())  then
      if LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType()) >= 0 then
	  return LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType()) 
end
 
else return ""
  
end
      
end

local function clip1()
  if IsValid(LocalPlayer():GetActiveWeapon()) then
      if (LocalPlayer():GetActiveWeapon():Clip1() >= 0) then
	  return LocalPlayer():GetActiveWeapon():Clip1()
	  end
end
   return ''
end


if lp:Alive() then
offsetY = 100
offsetX = 100

draw.RoundedBox(0, 0,(ScrH()-ScrH()/2)-ScrH()/2 ,ScrW(), 40, Color(0,200,255, 60))
draw.RoundedBox(0, (ScrW()/2)-360,(ScrH()-ScrH()/2)-ScrH()/2 ,(ScrW()/2)+70, 40, Color(255,255,0, 100))
draw.RoundedBox(0, 0,(ScrH()-ScrH()/2)-ScrH()/2 ,ScrW()-(ScrW()/2)-360, 40, Color(0,0,0, 150))
draw.RoundedBox(0,ScrW()-90,(ScrH()-ScrH()/2)-ScrH()/2 ,ScrW()-(ScrW()/2)-593, 40, Color(0,0,0,150))
draw.RoundedBox(10, 485,ScrH()- offsetY+20,200,50, Color(166,93,52, 150))
draw.RoundedBox(10, (ScrW()-ScrW()/2)+ScrW()/2-280,ScrH()- offsetY+20, 250, 50, Color(255,255,0, 42))


draw.RoundedBox(10, 55,ScrH()- offsetY+20, 200,50, Color(100, 0, 0, 150))
draw.RoundedBox(10, 270, ScrH()- offsetY+20,200,50, Color(0, 0, 100, 150))

if arm <= 100 then
draw.RoundedBox(10, 270, ScrH()- offsetY+20, math.Clamp(arm,0,150)*2, 50, Color(0, 70, 150, 255))
else 
draw.RoundedBox(10, 270, ScrH()- offsetY+20,200, 50, Color(0, 70, 150, 255))
end

--[[if food <= 100 then
draw.RoundedBox(10, 485, ScrH()- offsetY+5, math.Clamp(_G.food,0,150)*2,50 , Color(181, 63, 40, 200))
else 
draw.RoundedBox(10, 55, ScrH()- offsetY+5, 200,50, Color(181, 63, 40, 200))
end
--]]

if hp <= 100 then
draw.RoundedBox(10, 55, ScrH()- offsetY+20, math.Clamp(hp,0,150)*2,50 , Color(150, 40, 0, 255))
else 
draw.RoundedBox(10, 55,ScrH()- offsetY+20, 200,50, Color(150, 40, 0, 255))
end

local foodmat = Material("hud_icons/food.png")
	   surface.SetMaterial( foodmat )
       surface.SetDrawColor(255,255,255,255)
	   surface.DrawTexturedRect(494, ScrH()- offsetY+28, 30,30 )

local heartmat = Material("hud_icons/heart.png")
	   surface.SetMaterial( heartmat )
       surface.SetDrawColor(255,255,255,255)
	   surface.DrawTexturedRect( 65, ScrH()- offsetY+25, 42, 42 )
	   
local armormat = Material("hud_icons/armor.png")
	   surface.SetMaterial( armormat )
       surface.SetDrawColor(255,255,255,255)
	   surface.DrawTexturedRect( 280, ScrH()- offsetY+25, 35, 35 )
	   
local bulletsmat = Material("hud_icons/bullets.png")
	   surface.SetMaterial( bulletsmat )
       surface.SetDrawColor(255,255,255,255)
	   surface.DrawTexturedRect( (ScrW()-ScrW()/2)+ScrW()/2-280,ScrH()- offsetY+16, 55, 55 )
	   
	   
	   
draw.SimpleText('Job    :  '..job , 'Job',23,(ScrH()-ScrH()/2)-ScrH()/2+3, Color(0,255,255, 255))
draw.SimpleText('Money:  '.. money .. '$', 'Money' ,23,(ScrH()-ScrH()/2)-ScrH()/2+20, Color(150,255,0, 255))
draw.SimpleText(os.date("%H:%M",os.time()), 'Time' ,(ScrW()-ScrW()/2)+ScrW()/2-63,(ScrH()-ScrH()/2)-ScrH()/2+5, Color(0,0,0, 255))
draw.SimpleText(os.date("%d/%m/%Y",os.time()), 'Time' ,(ScrW()-ScrW()/2)+ScrW()/2-85,(ScrH()-ScrH()/2)-ScrH()/2+20, Color(0,0,0, 255))
draw.SimpleText('                   Welcome to the server '..rpname.. ' !', 'DCC-Ash',(ScrW()/2)-500,(ScrH()-ScrH()/2)-ScrH()/2+2, Color(0,80,150, 240))
draw.SimpleText(hp .. "%", 'DCC-Ash', 120,ScrH()- offsetY+26 , Color(c1,c2,c3,c4))
draw.SimpleText(arm .. "%", 'DCC-Ash', 330, ScrH()- offsetY+26 , Color(c5,c6,c7,c8))
draw.SimpleText(clip1()..'|'..reserveammo(),'Bullets', (ScrW()-ScrW()/2)+ScrW()/2-230,ScrH()- offsetY+30, Color(0, 0, 0, 255))

end
if !lp:Alive() then return false end

end

hook.Add("HUDPaint", "PaintHud", painthud)
hook.Add("HUDPaint", "PaintHud", food)
hook.Add('HUDShouldDraw','HudHIde', HideHud)