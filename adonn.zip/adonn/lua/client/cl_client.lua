print("Client lua loaded...")
hook.Add( "Think", "BM_Clients_Key", function()
	if input.IsKeyDown( KEY_G ) then
	print('thirdperson') end
end )