print("Server lua loaded...")
hook.Add( "KeyPress", "keypress_use_hi", function( ply, key )
	if ( key == KEY_G ) then
		print( "hi" )
	end
end )