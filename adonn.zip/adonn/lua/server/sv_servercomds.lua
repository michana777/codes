print("Server commands loaded...")

function checkhp (ply, text, team)
     local hp = ply:Health()
     if (hp < 1) then 
	 ply:Kill() 
	 end
end 

function kill(ply, text, team)
     if (string.lower(text) == "!kill") then
	 ply:KillSilent()
	 print ('Player ' .. ply:Name() .. ' killed himself')
	 end 
end

function subhp( ply, text, team)
local hp = ply:Health()
     if (string.lower(text) == "!hit") then
	 ply:SetHealth(hp - 10)
end 
     print('Ur hp is '..hp - 10)
end

function sethp( ply, text, team)
local hp = ply:Health()
     if (string.lower(text) == "!sethp") then
	 ply:SetHealth(10)
end 
     print('Ur hp is '..hp - 10)
end

function opensite (ply, text, team)
     local sendtext = {}
	 
	 text = string.lower(text)
	 
	 Opensite = {'!site','!si','!website','!web','!сайт','!вебсайт','!веб'}
	 
	 for k,v in pairs(Opensite) do
	 
	 if text == string.lower(v) then
	 
	 sendtext = {'bhvbvbv'}
	 ply:SendLua( [[  gui.OpenURL('https://vk.com/tkachoffmihail')  ]] )
	 
	 --дописать net функции
	 
	 end
end
end

hook.Add( "PlayerSay","PS",kill )
hook.Add( "PlayerSay","PS12",subhp )
hook.Add( "PlayerSay","PS1",checkhp )
hook.Add( "PlayerSay","PS21",sethp )
hook.Add( "PlayerSay","PS211",opensite )